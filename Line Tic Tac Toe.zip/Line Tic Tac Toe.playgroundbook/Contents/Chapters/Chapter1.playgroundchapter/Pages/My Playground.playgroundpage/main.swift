/*:
 
 # Welcome!
 
 Live Tic Tac Toe is a game playground that people of all ages can play together. ❌⭕️❌
 
 # What is the aim of the game? 🤔
 Win the game by supplying the same characters (XXX-OOO) from rows, columns or corners.
 
 # About the game 🧐
 -This is a strategy game for two players.
 
 -It is a game usually played in 3X3 table.
 
 -It is a game that can be played using pen and paper, but we will make use of technology.
 
 -Defense is at the forefront
 
 # Game rules 🤝
 
 -Same characters from rows, columns, or vertices The first player to provide (XXX -OOO) wins the game.
 
 -If there are no more moves to make, the game is drawn.
 
 -The first player makes her/his moves by typing "X" on an empty square and "O" on one of the empty squares for the other player.
 
 # Basic Strategies 🤓
 
 -Starting first is the biggest advantage.
 
 -It is advantageous to move corners when you first start out.
 
 -If you have started second and your opponent has moved to the corner, moving to the middle square is the first step to a good defense.
 
 
 
  ---
*/

//#-hidden-code
import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    var body: some View {
        GameView()
    }
}

PlaygroundPage.current.setLiveView(ContentView())
//#-end-hidden-code
