
import SwiftUI
import Combine
import CoreMotion

class MotionManager: ObservableObject {
    
    private var motionManager: CMMotionManager
    
    @Published var pitch: Double = 0.0
    @Published var roll: Double = 0.0
    @Published var rotation: CGFloat = 0.0
    
    init() {
        self.motionManager = CMMotionManager()
        self.motionManager.deviceMotionUpdateInterval = 1/60
        self.motionManager.startDeviceMotionUpdates(to: .main) { (motion, error) in
            guard error == nil else {
                print(error!)
                return
            }
            guard let deviceMotion = motion else { return }
            self.pitch = deviceMotion.attitude.pitch
            self.roll = deviceMotion.attitude.roll
            
        }
    }
}
