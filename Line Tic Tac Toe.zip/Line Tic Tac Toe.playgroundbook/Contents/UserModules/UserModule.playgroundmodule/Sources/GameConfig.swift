import SwiftUI

class GameConfig: ObservableObject {
    
    @Published var moves: [UIBezierPath] = Array(repeating: .none, count: 9)
    @Published var playerXScore: Int = 0
    @Published var playerOScore: Int = 0
    @Published var gameOver: Bool = false
    @Published var winningPlayer: UIBezierPath = .none
    @Published var Xamount: Bool = true
    @Published var Oamount: Bool = true
    
    func checkWinnigPlayer() {
        if checkMoves(player: .playerX) {
            self.playerXScore += 1
            self.gameOver = true
            self.winningPlayer = .playerX
        } else if checkMoves(player: .playerO) {
            self.playerOScore += 1
            self.gameOver = true
            self.winningPlayer = .playerO
        } else {
            let status = moves.contains { (value) -> Bool in
                return value == .none
            }
            if !status {
                gameOver.toggle()
            }
        }
    }
    
    func checkMoves(player: UIBezierPath) -> Bool {
        //Horizontal
        for h in stride(from: 0, to: 9, by: 3) {
            if moves[h] == player && moves[h + 1] == player && moves[h + 2] == player {
                return true
            }
        }
        //Vertical
        for v in 0...2 {
            if moves[v] == player && moves[v + 3] == player && moves[v + 6] == player {
                return true
            }
        }
        //Diagonal
        if moves[0] == player && moves[4] == player && moves[8] == player {
            return true
        }
        //Diagonal
        if moves[2] == player && moves[4] == player && moves[6] == player {
            return true
        }
        return false
    }
}
