import SwiftUI

struct ParallaxModifier: ViewModifier {
    
    @ObservedObject var manager: MotionManager
    
    var magnitude: Double
    func body(content: Content) -> some View {
        content
            .offset(x: CGFloat(manager.roll * magnitude), y: CGFloat(manager.pitch * magnitude))
    }
}
