
import SwiftUI
extension View {
    func parallaxEffect(manager: MotionManager, magnitude: Double) -> some View {
        self.modifier(ParallaxModifier(manager: manager, magnitude: magnitude))
    }
}
