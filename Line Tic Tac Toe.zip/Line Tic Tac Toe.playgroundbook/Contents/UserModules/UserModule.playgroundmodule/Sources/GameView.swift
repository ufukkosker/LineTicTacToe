
import SwiftUI

public struct GameView: View {
    @State var switchPlayer: Bool = false
    @State var restartGameButtonTapped: Bool = false
    @State var message = ""
    @ObservedObject var motionManager = MotionManager()
    @ObservedObject var gameConfig: GameConfig
    
    let columns = Array(repeating: GridItem(.flexible(minimum: 160, maximum: 160), spacing: 15), count: 3)
    let playerBounds = UIBezierPath.calculateBounds(paths: [.none, .playerX, .playerO])
    public init() {
        gameConfig = GameConfig()
    }
    public var body: some View {
        VStack {
            ScoreView(gameConfig: gameConfig)
            LazyVGrid(columns: columns, spacing:  15) {
                ForEach(self.gameConfig.moves.indices, id: \.self) { item in
                    GameCell(motionManager: .constant(self.motionManager), character: .constant(self.gameConfig.moves[item]), restartGame: $restartGameButtonTapped, gameOver: $gameConfig.gameOver)
                        .onTapGesture {
                            withAnimation(Animation.easeOut(duration: 0.5)) {
                                if self.gameConfig.moves[item] == .none {
                                    self.gameConfig.moves[item] = switchPlayer ? .playerX : .playerO
                                    self.switchPlayer.toggle()
                                }
                            }
                        }
                        .disabled(self.gameConfig.gameOver)
                }
            }
            Button(action: {
                
                withAnimation(Animation.easeOut(duration: 0.5)) {
                    self.restartGameButtonTapped = true
                }
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.gameConfig.moves.removeAll()
                    self.gameConfig.moves = Array(repeating: .none, count: 9)
                    self.restartGameButtonTapped = false
                    self.gameConfig.winningPlayer = .none
                    self.gameConfig.gameOver = false
                }
            }) {
                Text("Play Again")
                    .font(.system(size: 25, weight: .bold, design: .rounded))
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 15).stroke())
            }
            .parallaxEffect(manager: motionManager, magnitude: 20)
            .foregroundColor(Color(UIColor.label))
            .opacity(self.gameConfig.gameOver ? 1 : 0)
        }
        .frame(width: 500)
        .onChange(of: gameConfig.moves, perform: { value in
            withAnimation(Animation.easeInOut(duration: 0.5)) {
                gameConfig.checkWinnigPlayer()
            }
        })
    }
}

