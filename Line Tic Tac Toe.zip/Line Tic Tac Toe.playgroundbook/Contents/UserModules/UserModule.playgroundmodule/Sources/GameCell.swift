
import SwiftUI

struct GameCell: View {
    
    @State var endAmount: CGFloat = 1
    @State var onAppearAmount: CGFloat = 0
    @Binding var motionManager: MotionManager
    @Binding var character: UIBezierPath
    @Binding var restartGame: Bool
    @Binding var gameOver: Bool
    let playerBounds = UIBezierPath.calculateBounds(paths: [.none, .playerX, .playerO])
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 15)
                .trim(from: 0, to: onAppearAmount)
                .stroke()
                .overlay(RoundedRectangle(cornerRadius: 15).foregroundColor(Color(UIColor.secondarySystemBackground)).opacity(self.onAppearAmount == 1 ? 1 : 0))
            
            ShapeView(bezier: character, pathBounds: playerBounds)
                .trim(from: 0.0, to: self.character != .none ? endAmount : 0)
                .stroke()
                .frame(width: 155, height: 155, alignment: .center)
                .animation(.default)
                .parallaxEffect(manager: motionManager, magnitude: 15)
                .animation(.none)
        }
        .animation(.default)
        .parallaxEffect(manager: motionManager, magnitude: 15)
        .animation(.none)
        .frame(width: 160, height: 160)
        
        .onChange(of: self.restartGame, perform: { value in
            withAnimation(Animation.easeInOut(duration: 0.5)) {
                if value {
                    self.endAmount = 0
                } else {
                    self.endAmount = 1
                }
            }
        })
        .onAppear {
            withAnimation(.easeInOut(duration: 1)) {
                self.onAppearAmount = 1
            }
        }
    }
}
func calculatingWidth() -> CGFloat {
    let width = UIScreen.main.bounds.width - (30 + 30)
    return width / 3
}
