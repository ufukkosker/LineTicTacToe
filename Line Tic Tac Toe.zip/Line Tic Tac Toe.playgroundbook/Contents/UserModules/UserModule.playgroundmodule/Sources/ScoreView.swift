import SwiftUI

struct ScoreView: View {
    
    @ObservedObject var gameConfig: GameConfig
    let playerBounds = UIBezierPath.calculateBounds(paths: [.none, .playerX, .playerO])
    var body: some View {
        HStack {
            ShapeView(bezier: .playerX, pathBounds: playerBounds)
                .trim(from: 0, to: self.gameConfig.Xamount ? 1 : 0)
                .stroke()
                .frame(width: 50, height: 50)
            Text("\(gameConfig.playerXScore)")
                .font(.system(size: 30, weight: .bold, design: .rounded))
            Spacer()
            Text("\(gameConfig.playerOScore)")
                .font(.system(size: 30, weight: .bold, design: .rounded))
            ShapeView(bezier: .playerO, pathBounds: playerBounds)
                .trim(from: 0, to: self.gameConfig.Oamount ? 1 : 0)
                .stroke()
                .frame(width: 50, height: 50)
        }
        .animation(gameConfig.winningPlayer == .playerX ? Animation.easeOut(duration: 0.5).repeatCount(1, autoreverses: false) : .none, value: gameConfig.Xamount)
        .animation(gameConfig.winningPlayer == .playerO ? Animation.easeOut(duration: 0.5).repeatCount(1, autoreverses: false) : .none, value: gameConfig.Oamount)
        .onChange(of: gameConfig.winningPlayer, perform: { value in
            if value == .playerX {
                self.gameConfig.Xamount.toggle()
                withAnimation(Animation.easeInOut(duration: 0.5).delay(1)) {
                    self.gameConfig.Xamount = true
                }
            } else {
                self.gameConfig.Oamount.toggle()
                withAnimation(Animation.easeInOut(duration: 0.5).delay(1)) {
                    self.gameConfig.Oamount = true
                }
            }
        })
    }
}
