
import SwiftUI

struct ParticleEffectView: UIViewRepresentable {
    var particleImages: [UIBezierPath]
    func makeUIView(context: Context) -> UIView {
        
        let host = UIView(frame: CGRect(x: 0.0, y: 0.0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height))
        
        let particlesLayer = CAEmitterLayer()
        particlesLayer.frame = CGRect(x: 0.0, y: 0.0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        host.layer.insertSublayer(particlesLayer, at: 0)
        host.layer.masksToBounds = true
        host.insetsLayoutMarginsFromSafeArea = false
        particlesLayer.backgroundColor = .none
        particlesLayer.emitterShape = .rectangle
        particlesLayer.emitterPosition = CGPoint(x: UIScreen.main.bounds.width / 2, y: UIScreen.main.bounds.height / 2)
        particlesLayer.emitterSize = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        particlesLayer.emitterMode = .outline
        particlesLayer.renderMode = .backToFront
        
        particlesLayer.emitterCells = prepareParticeCell(particles: particleImages)
        return host
    }
    
    func prepareParticeCell(particles: [UIBezierPath]) -> [CAEmitterCell] {
        
        var arrayParticleCell: [CAEmitterCell] = [CAEmitterCell]()
        
        for particleItem in particles {
            
            let particleCell: CAEmitterCell = CAEmitterCell()
            
            particleCell.contents = UIImage.shapeImageWithBezierPath(bezierPath: particleItem, fillColor: .clear, strokeColor: .label)?.cgImage
            particleCell.name = "XO"
            particleCell.birthRate = 10
            particleCell.lifetime = 20.0
            particleCell.lifetimeRange = 0
            particleCell.velocity = 100
            particleCell.velocityRange = 100 / 4
            particleCell.emissionLongitude = .pi
            particleCell.emissionRange = .pi / 8
            particleCell.scale = 0.5
            particleCell.scaleRange = 0.5 / 3
            arrayParticleCell.append(particleCell)
            
        }
        
        return arrayParticleCell
    }
    func updateUIView(_ uiView: UIView, context: Context) {
        uiView.insetsLayoutMarginsFromSafeArea = false
        
    }
}
